/*
 * PostgreSQL DML for dropping the role and database for Pluralsight's 
 * course Apache Camel Introduction to Integration. This should be run 
 * when the database needs to be re-loaded. 
 */

DROP SCHEMA orders;
DROP DATABASE orders;
DROP ROLE orders;
